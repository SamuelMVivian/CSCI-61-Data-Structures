#include <iostream>
#include "table2.h"

using namespace std;
using namespace main_savitch_12B;



int main(){


Entry Sam1;
Sam1.key = 700;
Entry Sam2;
Sam2.key = 500;

table<Entry> test;
test.insert(Sam1);
cout<<"After entering Sam 1 into the table is he there? "<< test.is_present(Sam1.key)<<endl;
cout<<"After not entering Sam 2 into the table is he there? "<< test.is_present(Sam2.key)<<endl;
test.remove(Sam1.key);
cout<<"After removing Sam 1 from the table is he there? "<< test.is_present(Sam1.key)<<endl;
}
