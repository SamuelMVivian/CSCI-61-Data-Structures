#include <iostream>
#include<stack>
using namespace std;

//tree node struct
struct node
{
    char data;
    node* left, *right;
};

//traverses tree to output infix notation
void infix(node *t)
{
    if(t)
    {
        infix(t->left);
        cout<< t->data;
        infix(t->right);
    }
}

//checks for operators
bool isOperator(char c)
{
    if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^')  return true;
    return false;
}

//new node
node* newNode(int v)
{
    node *temp = new node;
    temp->left = temp->right = NULL;
    temp->data = v;
    return temp;
};


char* add(node** p, char* a)
{

    // Iat end of expression
    if (*a == '\0')
        return '\0';

    while (1) {
        char* q = "null";
        if (*p == NULL) {

            // Create a node with *a as the data and
            // both the children set to null
            node* n = (node*)malloc(sizeof(node));
            n->data = *a;
            n->left = NULL;
            n->right = NULL;
            *p = n;
        }
        else {

            // If the character is operand
            if (*a >= 'a' && *a <= 'z') {
                return a;
            }

            //left sub-tree
            q = add(&(*p)->left, a + 1);

            //right sub-tree
            q = add(&(*p)->right, q + 1);

            return q;
        }
    }
}

int main()
{
    node* s = NULL;
    cout<< "Enter Prefix expression: "<<endl;
    string b;
    cin >> b;
    char a[] = " ";
    for(int i = 0; i<b.length(); i++){
      a[i]=b[i];
    }
    add(&s, a);
    cout<< "The Infix expression is: ";
    infix(s);
    cout << endl;
    return 0;
}
