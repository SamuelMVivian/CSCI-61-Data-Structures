#include <iostream>
#include <time.h>
#include <queue>
#include <map>
#include <fstream>
using namespace std;

struct Student{
  //define < for Student
  bool operator < (const Student & rhs) const{
    if(priority < rhs.priority){
      return true;
    }else if(priority > rhs.priority){
      return false;
      //if equal defer to arrival time
    }else if(priority == rhs.priority){
      return (arrivalTime > rhs.arrivalTime);
    }
  }

  int waitTime;
  int processTime;
  int arrivalTime;
  int endTime;
  char topic;
  int priority;
  int name;
};


void officeHours(int &totalWait, int &totalProcess, int &totalTime, int &totalStudents, multimap<int,char> &info){
  //topic array
  char topics[] = "abcdefghijklmnopqrstuvwxyz";
  priority_queue<Student> students;
  int startTime = time(0);
  Student currentStudent;
  currentStudent.waitTime = -1;
  int secondsPassed = 0;

    while(difftime(time(0), startTime) < 60 || students.empty()==0 || currentStudent.waitTime != -1){
      //makes sure at max one student can show up per second
      if(time(0) - startTime > secondsPassed){
        //15% chance someone shows up and makes sure no one comes afte one hour
        if((rand() % 100 < 15) && difftime(time(0), startTime) < 60){
          //new student can stay random amount of time from 1-15 mins
          Student newStudent;
          newStudent.processTime = rand() % 15 + 1;
          newStudent.arrivalTime = time(0);
          //add "topic"
          newStudent.topic = topics[rand() % 26];
          //add "name"
          newStudent.name = rand() % 10;
          //random priority between 0 and 2
          newStudent.priority = rand() % 2;
          students.push(newStudent);
          totalStudents++;
        }
        secondsPassed++;
      }

      //if there are students in queue and the prof isnt helping anyone
      //add someone to currently helped student
      if(students.empty()==0 && currentStudent.waitTime == -1){
        currentStudent = students.top();
        currentStudent.waitTime = time(0) - currentStudent.arrivalTime;
        currentStudent.endTime = time(0) + currentStudent.processTime;

        //inserts info into multimap
        info.insert(pair<int,char>(currentStudent.name,currentStudent.topic));

        students.pop();
        totalProcess += currentStudent.processTime;
        totalWait += currentStudent.waitTime;
      }

      //after processign time student leaves so next student can be helped
      if(currentStudent.endTime < time(0) && currentStudent.waitTime != -1){
        currentStudent.waitTime = -1;
      }
    }

//add to total time
totalTime += difftime(time(0), startTime);
}

int main(){
  multimap<int,char> info;
  int tTotal = 0;
  int tWait = 0;
  int sTotal = 0;
  int tServed = 0;

  srand(time(NULL));

  for(int j = 0; j < 100; j++){
    officeHours(tWait, tServed, tTotal, sTotal, info);
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student0.txt");
    outfile << "Number of visits: " << info.count(0) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(0).first; it != info.equal_range(0).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student1.txt");
    outfile << "Number of visits: " << info.count(1) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(1).first; it != info.equal_range(1).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student2.txt");
    outfile << "Number of visits: " << info.count(2) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(2).first; it != info.equal_range(2).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student3.txt");
    outfile << "Number of visits: " << info.count(3) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(3).first; it != info.equal_range(3).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student4.txt");
    outfile << "Number of visits: " << info.count(4) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(4).first; it != info.equal_range(4).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }


  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student5.txt");
    outfile << "Number of visits: " << info.count(5) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(5).first; it != info.equal_range(5).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student6.txt");
    outfile << "Number of visits: " << info.count(6) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(6).first; it != info.equal_range(6).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student7.txt");
    outfile << "Number of visits: " << info.count(7) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(7).first; it != info.equal_range(7).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student8.txt");
    outfile << "Number of visits: " << info.count(8) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(8).first; it != info.equal_range(8).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student9.txt");
    outfile << "Number of visits: " << info.count(9) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(9).first; it != info.equal_range(9).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  cout << "Average time students spend waiting: " << tWait/sTotal << " minutes" <<endl;
  cout << "Avergae time students spend in office hours: " << tServed/sTotal << " minutes" << endl;
  cout << "Average time Professor spends past 1 hour: " << (tTotal/100) - 60 << " minutes" << endl;

  return 0;
}
