#include <iostream>
#include "HW1.h"
using namespace std;

int main()
{
    cout << "Enter an equation in infix notation: ";
    string s;
    cin >> s;
    cout << infixToPrefix(s) <<endl;

    cout << "Enter an equation in prefix notation: ";
    string s2;
    cin >> s2;
    cout << prefixToInfix(s2) << endl;
    
    return 0;
}
