#include <iostream>
#include "set.h"

using namespace std;

int main() {
	set<int> test;
	int add_remove;
	do {
		cout << "Enter integer to B-tree (-1 to quit): ";
		cin >> add_remove;
		if (add_remove != -1) {
			test.insert(add_remove);
			cout << endl;
			test.print(0);
			cout << endl;
		}
	} while (add_remove != -1);

	cout << endl;
	test.print(0);
	cout << endl;

	do {
		cout << "Enter integer to be removed from B-tree (-1 to quit): ";
		cin >> add_remove;
		if (add_remove != -1) {
			test.erase(add_remove);
			cout << endl;
			test.print(0);
			cout << endl;
		}
	} while (add_remove != -1);
}
