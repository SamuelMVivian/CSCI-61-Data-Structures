#include <iostream>

using namespace std;

//calculates number of trees with n nodes
//In order to get the number of possible trees created with n nodes
//one needs to add together the possibilities of all previous trees
//in which the combination of two smaller trees combined equals the
//correct amount of nodes. For every two trees, a and b that can be combined
//to get the desired n node tree, there are numberOfTrees(a)*numberOfTrees(b) ways
//to combine them. Since a can be any number from 1 to n and b is n-a the
//recursive formula below follows.
int numberOfTrees(int n){
  if(n<=1) return 1;

  int num = 0;
  for(int i = 0; i < n; i++){
    num += numberOfTrees(i)*numberOfTrees(n-i-1);
  }

  return num;
}

int main(){

  cout<< numberOfTrees(3) << " trees with 3 nodes" << endl;
  cout<< numberOfTrees(4) << " trees with 4 nodes" << endl;
}
