#include <iostream>
#include "bag6.h"
using namespace std;
using namespace main_savitch_10;

template <class Item>
void rearrange(binary_tree_node<Item>*& root)
{
  int largest = root->data();
  int lORr = 0;
  binary_tree_node<Item>* left = root->left();
  binary_tree_node<Item>* right = root->right();

  if (root == nullptr) return;

  if(left!=nullptr&&left->data()>largest){
    largest = left->data();
  }

  if(right!=nullptr&&right->data()>largest){
    largest = right->data();
    lORr = 1;
  }

  if(largest!=root->data()){
    if(lORr == 0){
      left->set_data(root->data());
      root->set_data(largest);
    }else{
      right->set_data(root->data());
      root->set_data(largest);
    }
  }

  if(left!=nullptr){
    rearrange(left);
  }
  if(right!=nullptr){
    rearrange(right);
  }
}

template <class Item>
void heapify(binary_tree_node<Item>*& root,int size)
{
  for(int i=0; i<size; i++){
    rearrange(root);
  }
}
int main()
{
bag<int> test;
test.insert(4);
test.insert(2);
test.insert(6);
test.insert(1);
test.insert(3);
test.insert(5);
test.insert(7);
test.insert(4);
test.insert(2);
test.insert(6);
test.insert(1);
test.insert(3);
test.insert(5);
test.insert(7);


binary_tree_node<int>* pls = test.get_root();
print(pls,0);
int yuh = test.size();
cout<<"\n\n\n\n\n";
heapify(pls,yuh);
print(pls,0);
}
