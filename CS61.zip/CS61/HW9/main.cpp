#include <iostream>
#include "graph.h"

using namespace std;
using namespace main_savitch_15;

int main(){
graph<int> test;
size_t max= 0;
for(int i = 0; i<7; i++)
{
  test.add_vertex(i);
}
test.add_edge(0,1);
test.add_edge(0,4);
test.add_edge(2,0);
test.add_edge(3,0);
test.add_edge(3,5);
test.add_edge(3,6);
test.add_edge(6,1);
test.add_edge(1,3);

cout<<test.longestDistance(0,6)<<endl;
cout<<test.longestDistance(2,6)<<endl;
cout<<test.longestDistance(2,5)<<endl;
cout<<test.longestDistance(0,5)<<endl;
cout<<test.longestDistance(0,1)<<endl;
cout<<test.longestDistance(0,0)<<endl;
cout<<test.longestDistance(0,3)<<endl;
cout<<test.longestDistance(5,0)<<endl;
}
