#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void findWord(char grid[1000][1000], string target, int r, int c);
void findSize(string puzzle, int& r, int& c);
void wordSearcher(string puzzle, string dict);
void makeGrid(char grid[1000][1000], string puzzle, int r, int c);
bool search(char grid[1000][1000], string target, int r, int c, int row, int col, int &dir);


//solve word searches up to 1000 by 1000
void wordSearcher(string puzzle, string dict){
  ifstream words;
  words.open(dict);
  string temp;
  int r = 0;
  int c = 0;

  findSize(puzzle,r,c);
  char grid[1000][1000];
  makeGrid(grid, puzzle,r,c);

  while(getline(words, temp)){
    if (temp.length()>5){
      findWord(grid, temp, r, c);
    }
  }
  words.close();
}


//gets the coluns and rows in the puzzle
void findSize(string puzzle, int& r, int& c){
  r = 0;
  ifstream grid;
  grid.open(puzzle);
  string temp;
  while(getline(grid,temp)){
    c = (temp.length()/2);
    r++;
  }
  grid.close();
}



//reads puzzle into a 2D array
void makeGrid(char grid[1000][1000], string puzzle, int r, int c){
  ifstream infile;
  infile.open(puzzle);
  for(int i = 0; i < r; i++){
    for(int j = 0; j < c; j++){
      infile >> grid[i][j];
    }
  }
  infile.close();
}

//searches from give coordinate in all 8 directions
bool search(char grid[1000][1000], string target, int r, int c, int row, int col, int &dir){
  int x[] = { -1, -1, -1, 0, 0, 1, 1, 1 };
  int y[] = { -1, 0, 1, -1, 1, -1, 0, 1 };

  if (grid[row][col] != target[0])
      return false;

    int len = target.length();

    for (dir = 0; dir < 8; dir++)
    {
        int k, rowd = row + x[dir], cold = col + y[dir];

        for (k = 1; k < len; k++)
        {
            if (rowd >= r || rowd < 0 || cold >= c || cold < 0){
                break;
              }

            if (grid[rowd][cold] != target[k]){
                break;
              }

            rowd += x[dir], cold += y[dir];
        }

        if (k == len){
            return true;
          }
    }
    return false;
}


//calls search through whole puzzle
void findWord(char grid[1000][1000], string target, int r, int c){
  int x[] = { -1, -1, -1, 0, 0, 1, 1, 1 };
  int y[] = { -1, 0, 1, -1, 1, -1, 0, 1 };
  for (int row = 0; row < r; row++)
         for (int col = 0; col < c; col++){
           int dir;
           int found = search(grid, target, r, c, row, col, dir);
            if (found){
              int endr = row + (target.length()-1)*x[dir];
              int endc = col + (target.length()-1)*y[dir];
              cout << target <<" from (" << row << ", " << col << ")" << " to (" << endr << ", " << endc << ")"<<endl;
             }
           }
}



int main(){
  wordSearcher("puzzle.txt", "words.txt");
}
