#include <algorithm>
#include <iostream>
#include <stack>
using namespace std;

//returns a number for order of operations
int pemdos(char o)
{
    if (o == '-' || o == '+')
        return 1;
    else if (o == '*' || o == '/')
        return 0;
    return 2;
}

//changes infix to prefix notation
string infixToPrefix(string infix){

  //reverse infix
  reverse(infix.begin(),infix.end());

  //switch directions of all parenthesis to finish reversal
  for (int i = 0; i < infix.size(); i++) {
      if (infix[i] == '(') {
          infix[i] = ')';
          i++;
      }
      else if (infix[i] == ')') {
          infix[i] = '(';
          i++;
      }
  }

//add parenthesis so the stack has a clear beginning and end
  infix = '(' + infix + ')';

//initialize stack for opertors and a result string
  stack<char> opStack;
  string result;

//loop through infix
  for(int i = 0; i < infix.size(); i++){

    //appends any digit or character to result
    if(isalpha(infix[i]) || isdigit(infix[i]))
      result+=infix[i];

    //pushes ( onto stack and then pops it from the stack if the
    //loop sees ) and ( is the top of the stack
    //if ( is not the top of the stack append the top to result and pops
    else if (infix[i] == '(')
        opStack.push('(');
    else if (infix[i] == ')'){
      while (opStack.top() != '(') {
        result += opStack.top();
        opStack.pop();
      }
      opStack.pop();
    }

    //while operator in input has greater value than the top of the stack
    // append to result and pop from stack
    //otherwise push operator from infix to stack
    else{
      if(!isalpha(opStack.top()) && !isdigit(opStack.top())){
        while (pemdos(infix[i]) >= pemdos(opStack.top())){
          result += opStack.top();
          opStack.pop();
        }
        opStack.push(infix[i]);
      }
    }
  }

//reverse result
  reverse(result.begin(), result.end());
  return result;
}

//changes prefix to infix notation
string prefixToInfix(string prefix){
  //initialized stack with a string on it
  stack<string> sStack;

//loops through prefix from right to left
  for (int i = prefix.size() - 1; i >= 0; i--) {

    //if input is operator pop two operands from stack and put
    //them together with operator in between surrounded by parenthesis
    //then push back to stack
    if(pemdos(prefix[i]) == 0 || pemdos(prefix[i]) == 1){
      string operand1 = sStack.top();
      sStack.pop();
      string operand2 = sStack.top();
      sStack.pop();

      string temp = "(" + operand1 + prefix[i] + operand2 + ")";
      sStack.push(temp);

      //pushes operand to stack
    }else{
      sStack.push(string(1,prefix[i]));
    }
  }

  return sStack.top();
}
