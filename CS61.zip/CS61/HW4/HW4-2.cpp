#include <iostream>
#include <time.h>
#include <queue>
using namespace std;

struct Student{
  //define < for Student
  bool operator < (const Student & rhs) const{
    if(priority < rhs.priority){
      return true;
    }else if(priority > rhs.priority){
      return false;
      //if equal defer to arrival time
    }else if(priority == rhs.priority){
      return (arrivalTime > rhs.arrivalTime);
    }
  }

//added priority definitition
  int waitTime;
  int processTime;
  int arrivalTime;
  int endTime;
  int priority;
};


void officeHours(int &totalWait, int &totalProcess, int &totalTime, int &totalStudents){
  priority_queue<Student> students;
  int startTime = time(0);
  Student currentStudent;
  currentStudent.waitTime = -1;
  int secondsPassed = 0;

    while(difftime(time(0), startTime) < 60 || students.empty()==0 || currentStudent.waitTime != -1){
      //makes sure at max one student can show up per second
      if(time(0) - startTime > secondsPassed){
        //15% chance someone shows up and makes sure no one comes afte one hour
        if((rand() % 100 < 15) && difftime(time(0), startTime) < 60){
          //new student can stay random amount of time from 1-15 mins
          Student newStudent;
          newStudent.processTime = rand() % 15 + 1;
          newStudent.arrivalTime = time(0);
          //added random priority between 0 and 2
          newStudent.priority = rand() % 2;
          students.push(newStudent);
          totalStudents++;
        }
        secondsPassed++;
      }

      //if there are students in queue and the prof isnt helping anyone
      //add someone to currently helped student
      if(students.empty()==0 && currentStudent.waitTime == -1){
        currentStudent = students.top();
        currentStudent.waitTime = time(0) - currentStudent.arrivalTime;
        currentStudent.endTime = time(0) + currentStudent.processTime;
        students.pop();
        totalProcess += currentStudent.processTime;
        totalWait += currentStudent.waitTime;
      }

      //after processign time student leaves so next student can be helped
      if(currentStudent.endTime < time(0) && currentStudent.waitTime != -1){
        currentStudent.waitTime = -1;
      }
    }

//add to total time
totalTime += difftime(time(0), startTime);
}

int main(){
  int tTotal = 0;
  int tWait = 0;
  int sTotal = 0;
  int tServed = 0;

  srand(time(NULL));

  for(int i = 0; i < 100; i++){
    officeHours(tWait, tServed, tTotal, sTotal);
  }

  cout << "Average time students spend waiting: " << tWait/sTotal << " minutes" <<endl;
  cout << "Avergae time students spend in office hours: " << tServed/sTotal << " minutes" << endl;
  cout << "Average time Professor spends past 1 hour: " << (tTotal/100) - 60 << " minutes" << endl;

  return 0;
}
