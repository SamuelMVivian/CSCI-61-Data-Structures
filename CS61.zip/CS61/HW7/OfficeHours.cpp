#include <iostream>
#include <time.h>
#include <queue>
#include <map>
#include <fstream>
#include <algorithm>
using namespace std;

struct Student{
  //define < for Student
  bool operator < (const Student & rhs) const{
    if(priority < rhs.priority){
      return true;
    }else if(priority > rhs.priority){
      return false;
      //if equal defer to arrival time
    }else if(priority == rhs.priority){
      return (arrivalTime > rhs.arrivalTime);
    }
  }

  int waitTime;
  int processTime;
  int arrivalTime;
  int endTime;
  char topic;
  int priority;
  int name;
};


void officeHours(int &totalWait, int &totalProcess, int &totalTime, int &totalStudents, multimap<int,char> &info){
  //topic array
  char topics[] = "abcdefghijklmnopqrstuvwxyz";
  priority_queue<Student> students;
  int startTime = time(0);
  Student currentStudent;
  currentStudent.waitTime = -1;
  int secondsPassed = 0;

    while(difftime(time(0), startTime) < 60 || students.empty()==0 || currentStudent.waitTime != -1){
      //makes sure at max one student can show up per second
      if(time(0) - startTime > secondsPassed){
        //15% chance someone shows up and makes sure no one comes afte one hour
        if((rand() % 100 < 15) && difftime(time(0), startTime) < 60){
          //new student can stay random amount of time from 1-15 mins
          Student newStudent;
          newStudent.processTime = rand() % 15 + 1;
          newStudent.arrivalTime = time(0);
          //add "topic"
          newStudent.topic = topics[rand() % 26];
          //add "name"
          newStudent.name = rand() % 10;
          //random priority between 0 and 2
          newStudent.priority = rand() % 2;
          students.push(newStudent);
          totalStudents++;
        }
        secondsPassed++;
      }

      //if there are students in queue and the prof isnt helping anyone
      //add someone to currently helped student
      if(students.empty()==0 && currentStudent.waitTime == -1){
        currentStudent = students.top();
        currentStudent.waitTime = time(0) - currentStudent.arrivalTime;
        currentStudent.endTime = time(0) + currentStudent.processTime;

        //inserts info into multimap
        info.insert(pair<int,char>(currentStudent.name,currentStudent.topic));

        students.pop();
        totalProcess += currentStudent.processTime;
        totalWait += currentStudent.waitTime;
      }

      //after processign time student leaves so next student can be helped
      if(currentStudent.endTime < time(0) && currentStudent.waitTime != -1){
        currentStudent.waitTime = -1;
      }
    }

//add to total time
totalTime += difftime(time(0), startTime);
}



//column = 0 means sort by student. column = 1 means sort by topics
//direction = 0 means ascending, direction = 1 means descending
void sortFile(string filename, bool column, bool direction){
string names[1000];
string topic[1000];
string Trash;
ifstream fin;
fin.open(filename);
fin >> Trash >> Trash;
int n = 0;
while(fin >> names[n] >> topic[n]){
  n++;
}
fin.close();
//int n = sizeof(names)/sizeof(names[0]);

//sort by student, ascending
if(column == 0 && direction == 0){
  int i,j,index;
  for(i = 0; i < n-1; i++){
    index = i;
    for(j=i+1; j<n;j++){
      if (names[j]< names[index]){
        index = j;
      }
      swap(names[index],names[i]);
      swap(topic[index],topic[i]);
    }
  }
}
//sort by topic, ascending
if(column == 1 && direction == 0){
  int i,j,index;
  for(i = 0; i < n-1; i++){
    index = i;
    for(j=i+1; j<n;j++){
      if (topic[j]< topic[index]){
        index = j;
      }
      swap(names[index],names[i]);
      swap(topic[index],topic[i]);
    }
  }
}
//sort by names, descending
if(column == 0 && direction == 1){
  int i,j,index;
  for(i = n-1; i >= 0; i--){
    index = i;
    for(j=i; j>=0;j--){
      if (names[j]< names[index]){
        index = j;
      }
      swap(names[index],names[i]);
      swap(topic[index],topic[i]);
    }
  }
}

//sort by topics, descending
if(column == 1 && direction == 1){
  int i,j,index;
  for(i = n-1; i >= 0; i--){
    index = i;
    for(j=i; j>=0;j--){
      if (topic[j]< topic[index]){
        index = j;
      }
      swap(names[index],names[i]);
      swap(topic[index],topic[i]);
    }
  }
}

ofstream sorted;
sorted.open("sorted.txt");
sorted << "Name "<< "Topic"<<endl;
for(int i = 0; i<n;i++){
  sorted<<names[i]<<" "<<topic[i]<<endl;
  cout<<names[i]<<topic[i]<<endl;
}
sorted.close();
}



int main(){
  multimap<int,char> info;
  int tTotal = 0;
  int tWait = 0;
  int sTotal = 0;
  int tServed = 0;

  srand(time(NULL));

  for(int j = 0; j < 100; j++){
    officeHours(tWait, tServed, tTotal, sTotal, info);
  }

  for(int i = 0; i<10; i++){
    ofstream outfile;
    outfile.open("Student"+to_string(i)+".txt");
    outfile << "Number of visits: " << info.count(i) <<endl;
    int count = 0;
    for(multimap<int,char>::iterator it = info.equal_range(i).first; it != info.equal_range(i).second; it++){
      outfile << "Topic " << count+1 << ": " << it->second << endl;
      count++;
    }
    outfile.close();
  }

  ofstream file;
  file.open("master.txt");
  file << "Name "<< "Topic"<<endl;
  for(auto it = info.begin(); it != info.end(); it++){
    file << it -> first << " " << it -> second << endl;
  }
  file.close();

  sortFile("master.txt", 1, 1);


  cout << "Average time students spend waiting: " << tWait/sTotal << " minutes" <<endl;
  cout << "Avergae time students spend in office hours: " << tServed/sTotal << " minutes" << endl;
  cout << "Average time Professor spends past 1 hour: " << (tTotal/100) - 60 << " minutes" << endl;

  return 0;
}
